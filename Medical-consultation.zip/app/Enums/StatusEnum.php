<?php

namespace App\Enums;

enum StatusEnum: string
{
    case active = '1';
    case deactive = '0';
   
}