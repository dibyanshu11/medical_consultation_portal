<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class RegisterOtp extends Mailable
{
    use Queueable, SerializesModels;


    public $otp;
    public $input;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($otp,$input)
    {
        $this->otp = $otp;
        $this->input=$input;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {

        return $this->from('navdeepkumar24@yopmail.com','Medical Consultation')
                     ->subject('Register Otp')
                     ->view('api.emails.register_otp');

    }
}
