<p style="color:#3d4852;font-size: 16px;line-height:1.5em;"><h4>Hi,{{@$input['first_name']}}</h4></p>
<p style="color:#3d4852;font-size: 16px;line-height:1.5em;"><h4>Welcome To Medical Consultation, </h4></p>
<p style="color:#3d4852;font-size: 16px;line-height:1.5em;">Your OTP for Register: <b>{{$otp}}</b> </p>